import React, { useEffect, useRef } from "react";
import lottie from "lottie-web";
import successAnimation from "./data.json";
import { Box, Typography } from "@mui/material";
import { useDispatch } from "react-redux";
import { showToggling } from "../redux/productsSlice";
import { AppDispatch } from "../redux/Store";

const SuccessAnimation = ({ onAnimationEnd }: any) => {
  // console.log(lottie,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
  const lottieContainerRef = useRef(null);
  const dispatch = useDispatch<AppDispatch>();
  useEffect(() => {
    const container = lottieContainerRef.current;

    if (container) {
      const animation = lottie.loadAnimation({
        container,
        renderer: "svg",
        loop: false,
        autoplay: true,
        animationData: successAnimation,
      });

      lottie.setSpeed(1.5);

      animation.addEventListener("complete", () => {
        if (onAnimationEnd) {
          onAnimationEnd();
          dispatch(showToggling());
        }
      });

      return () => {
        animation.stop();
        animation.destroy();
      };
    }
  }, [onAnimationEnd]);

  return (
    <>
    <Box
      ref={lottieContainerRef}
      sx={{
        width: "500px",
        height: "700px",
        position: "absolute",
        marginLeft: "600px",
      }}
    />
    <Typography>Placed sucess</Typography>
    </>
  );
};

export default SuccessAnimation;
