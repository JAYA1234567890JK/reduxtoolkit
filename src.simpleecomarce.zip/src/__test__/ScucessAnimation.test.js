// import React from 'react';
// import { Container, render, unmountComponentAtNode } from 'react-dom';
// import { act } from 'react-dom/test-utils';
// import * as lottie from 'lottie-web'; // Import lottie
// import SuccessAnimation from '../screens/SucessANimation';
// 
// jest.mock('lottie-web'); // Mock lottie package
// 
// let container
// 
// beforeEach(() => {
  // container = document.createElement('div');
  // document.body.appendChild(container);
// });
// 
// afterEach(() => {
  // unmountComponentAtNode(container);
  // container.remove();
// });
// 
// it('renders without crashing', () => {
  // render(<SuccessAnimation />, container);
  // expect(lottie.loadAnimation).toHaveBeenCalledTimes(1); 
// });
// 
// it('displays the "Placed success" text', () => {
  // act(() => {
    // render(<SuccessAnimation />, container);
  // });
  // const text = container.querySelector('Typography');
  // expect(text.textContent).toBe('Placed success');
// });
// 
// Add more test cases for animation behavior if needed
