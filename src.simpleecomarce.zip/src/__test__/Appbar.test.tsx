import React from "react";
import { render, getByText } from "@testing-library/react";
import Appbar from "../screens/Appbar";
import configureStore from "redux-mock-store";
import thunk from "redux-thunk";
import { Provider } from "react-redux";
import { ThemeProvider } from "@mui/styles";
import { createTheme } from "@mui/material";
import SuccessAnimation from "../screens/SucessANimation";
jest.mock("lottie-web", () => {
  const listeners: { [key: string]: Function } = {};

  const lottie = {
    loadAnimation: jest.fn(),
    setSpeed: jest.fn(),
    addEventListener: (eventName: string, callback: Function) => {
      listeners[eventName] = callback;
    },
    removeEventListener: (eventName: string) => {
      delete listeners[eventName];
    },
    triggerCompleteEvent: () => {
      if (listeners["complete"]) {
        listeners["complete"]();
      }
    },
  };

  return lottie;
});
const onAnimationEnd = jest.fn();
const mockStore = configureStore([thunk]);
const theme = createTheme();
const store = {
  productsSlice: {
    products: [],
    shopingCart: [],
    favarateToCartArr: [],
    filterData: [],
    loading: false,
    showSucess: true,
    payAfter: false,
    couponApplied: false,
  },
};

const loadingStore = {
  productsSlice: {
    products: [],
    shopingCart: [],
    favarateToCartArr: [],
    filterData: [],
    loading: true,
    showSucess: false,
    payAfter: false,
    couponApplied: false,
  },
};

// test("Renders SuccessAnimation component", () => {
//   const { getByTestId } = render(
    // <SuccessAnimation onAnimationEnd={jest.fn()} />
//   );
// 
//   const successText = getByTestId("Placed success");
//   expect(successText).toBeInTheDocument();
// });

// test("Renders Appbar componet with a Redux store", () => {
//   render(
    // <ThemeProvider theme={theme}>
      {/* <Provider store={mockStore(store)}> */}
        {/* <Appbar /> */}
      {/* </Provider> */}
    {/* </ThemeProvider> */}
//   );
// });

test("Renders a loading spinner when loading is true", () => {
  const { getByTestId } = render(
    <ThemeProvider theme={theme}>
      <Provider store={mockStore(loadingStore)}>
        <Appbar />
      </Provider>
    </ThemeProvider>
  );
  const loadingSpinner = getByTestId("loading-spinner");
  expect(loadingSpinner).toBeInTheDocument();
});
